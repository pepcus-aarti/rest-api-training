package com.employee.example.data;

/**
 * This class has department name and employee name field.
 * For finding all department name with corresponding employee name.
 * @author Aarti
 *
 */

public class DeptEmpDto {
	
	private String deptName;
	private String empName;
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public DeptEmpDto(String deptName, String empName) {
		super();
		this.deptName = deptName;
		this.empName = empName;
	}
	
	public DeptEmpDto() {
		
	}
	
	

}
